==================================================================
Breakthrough Server Fixes for Breakthrough v2.40
version: 100809 (REPACK) - 09/08/10 (DD/MM/YY)
by Daven
==================================================================

Unofficial patch that fixes most known game bugs and adds some
new features 

==================================================================
INSTALLATION
==================================================================

First make a backup of your moh_Breakthrough_server.exe and copy
these files in your MOHAA directory:

-BTPatch.dll (optional)
-moh_Breakthrough_server.exe
-maintt\autoexec2.cfg
-maintt\dgamex86.dll
-maintt\listip.cfg
-maintt\PK3_Fixes_BT_2.40_(101231).dpk3

------------------------------------------------------------------
It should look like this:

"MOHAA" directory (C:\program files\EA GAMES\MOHAA\)
-BTPatch.dll
-moh_Breakthrough_server.exe

"MOHAA\maintt" directory (C:\program files\EA GAMES\MOHAA\maintt\)
-autoexec2.cfg
-dgamex86.dll
-listip.cfg
-PK3_Fixes_BT_2.40_(101231).dpk3

("C:\program files\EA GAMES" is just an example of where i have
the game installed)

------------------------------------------------------------------
IMPORTANT: Make sure you are running the server with the dedicated
executable moh_Breakthrough_server.exe otherwise my patch will not
get loaded

If you have rented a dedicated server and the host runs the server
with moh_Breakthrough.exe, delete or rename it, copy
moh_Breakthrough_server.exe from my patch and rename it to
moh_Breakthrough.exe (thanks to Krones for this trick)

==================================================================
FEATURES
==================================================================

* Fixes
  - leave_team
  - callvote default votation list
  - cheats - Turns client cheats off/on (r_farplane_nofog,
    r_lightmap, cg_3rd_person, etc). Can be bypassed
  - Sys_SendPacket: bad address type
  - callvote text overflow
  - buffer-overflow
  - directory traversal
  - q3rconz
  - anti-shark
  - fps models
  - getting weapons from opposite team
  - getting weapons from different nationality
  - infinite nade charging
  - nade crash bug
  - door nade bug
  - time/numSnapshotEntities wrapping

* New commands
  - Cvar "sv_cheats 0/1": Turns server cheats off/on (wuss, dog,
    give, etc)
  - Scripting command "adddeaths": Give or take deaths from the
    player
  - Server command "dumpclient [client number]": Shows info from
    clients
  � Server command "sv [command]" (Eg.: sv addip 1.2.3.4)
    - addip [ip address]: Adds a single IP or IP mask to the
      banned list
    - removeip [ip address]: Removes a single IP or IP mask from
      the banned list
    - writeip: Saves banned ips to maintt/listip.cfg
    - listip: Lists banned ips to the console

* Other
  - "sv_allowdownload 0" and "g_dropclips -1" by default
  - "g_shownpc" doesn't turn to 1 when developer is 1
  - RunningBon's dll patched to work with Breakthrough
  - High/Low ping kick screen
  - Commands "dumpuser" and "reloadmap" revised
  - In-game chat text length limit changed to two lines per player
  - In-game chat prefix "(all)"

==================================================================
CREDITS
==================================================================

A list of fixes included in my patch that were not made by me:

(Author and fixes)

Elgan
- anti-shark
- original fps fix script (my fix is based on his script)
- script strings.scr

Luigi Auriemma
- buffer-overflow
- directory traversal
- q3rconz

RunningBon
- BTPatch.dll

sorridstroker
- weapons from opposite team

------------------------------------------------------------------
Thanks to everyone who helped me in testing, suggestions, etc:

bigidigi
Creaper
Herr Klugscheisser
Krones
LeBabouin
modder
nanobahr
supportMOH
vuurvent
